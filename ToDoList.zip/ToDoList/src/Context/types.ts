import type { Dispatch } from "react"

export type ToDo = {
    id: number
    title: string
    completed: boolean
}

export type Action = {
    type: string
    payload?: unknown
}

export type ContextType = {
    state: State
    dispatch: Dispatch<Action>
}

export type FilterType = "All" | "Active" | "Completed"

export type State = {
    todos: ToDo[]
    currentFilter: FilterType
}