import type { Action, State } from "./types"

export const reducer = (state: State, action: Action): State => {
    switch (action.type) {
        case "REMOVE":
            return {
                ...state,
                todos: state.todos.filter(
                    todo => todo.id !== action.payload
                )
            }

        case "ADD":
            return {
                ...state,
                todos: [
                    {
                        title: action.payload as string,
                        id: Date.now(),
                        completed: false
                    },
                    ...state.todos
                ]
            }

        case "UPDATE":
            return {
                ...state,
                todos: state.todos.map(todo => {
                    return todo.id !== action.payload
                        ? todo
                        : {
                            ...todo,
                            completed: !todo.completed
                        }
                })
            }

        case "SET_FILTER":
            return {
                ...state,
                currentFilter: action.payload as State["currentFilter"]
            }

        default:
            return state
    }
}