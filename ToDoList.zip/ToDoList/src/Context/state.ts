import type { State } from "./types";

export const initialState: State = {
    todos: [{
        id: 1,
        title: "Learn React",
        completed: false,
    },
    {
        id: 2,
        title: "Practice TypeScript",
        completed: true,
    }],
    currentFilter: "All"
}