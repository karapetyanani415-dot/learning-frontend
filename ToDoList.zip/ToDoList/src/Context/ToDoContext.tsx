import React from "react";
import type { ContextType } from "./types";
export const ToDoContext = React.createContext<ContextType | null>(null)