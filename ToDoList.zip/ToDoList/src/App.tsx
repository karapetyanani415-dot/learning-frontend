import { useReducer } from "react"
import { ToDoList } from "./components/ToDoList"
import { reducer } from "./Context/reducer"
import { initialState } from "./Context/state"
import { ToDoContext } from "./Context/ToDoContext"

export default function App() {
    const [state, dispatch] = useReducer(reducer, initialState) 

    return (
        <ToDoContext.Provider value={{ state, dispatch }}>
            <ToDoList />
        </ToDoContext.Provider>
    )
}