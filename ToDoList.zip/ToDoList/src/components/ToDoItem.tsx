import type React from "react"
import type { ToDo } from "../Context/types"
import { useContext } from "react"
import { ToDoContext } from "../Context/ToDoContext"

type Props = {
    todo: ToDo
}

export const ToDoItem: React.FC<Props> = ({ todo }) => {
    const context = useContext(ToDoContext)
    if (!context) throw new Error("Out of provider")

    const { dispatch } = context
    return (
        <li className={`flex items-center justify-between rounded-2xl border p-4 shadow-sm transition-colors ${todo.completed
                ? "bg-emerald-50 border-emerald-200"
                : "bg-white border-slate-200 hover:border-emerald-200"
            }`}>
            <div className="flex items-center space-x-3">
                <input
                    type="checkbox"
                    checked={todo.completed}
                    readOnly
                    className="h-5 w-5 text-emerald-600 focus:ring-emerald-500 border-slate-300 rounded"
                />
                <h3 className={`text-lg font-medium ${todo.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                    {todo.title}
                </h3>
            </div>
            <div className="flex items-center space-x-2">
                <button type="button" onClick={() => dispatch({ type: "UPDATE", payload: todo.id })} className="px-3 py-1.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors focus:outline-none focus:ring-4 focus:ring-emerald-200">
                    {todo.completed ? 'Undo' : 'Complete'}
                </button>
                <button onClick={() => dispatch({ type: "REMOVE", payload: todo.id })} className="px-3 py-1.5 bg-rose-50 text-rose-600 border border-rose-200 rounded-xl hover:bg-rose-100 transition-colors focus:outline-none focus:ring-4 focus:ring-rose-100">
                    Delete
                </button>
            </div>
        </li>
    )
}