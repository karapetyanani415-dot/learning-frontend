import { useForm, type SubmitHandler } from "react-hook-form"
import type { ToDo } from "../Context/types"
import { useContext } from "react"
import { ToDoContext } from "../Context/ToDoContext"

type Props = Omit<ToDo, "id" | "completed">

export const AddToDo = () => {
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm<Props>()

    const context = useContext(ToDoContext)

    if (!context) {
        throw new Error("Out of provider")
    }

    const { dispatch } = context

    const onSubmit: SubmitHandler<Props> = (data) => {
        dispatch({
            type: "ADD",
            payload: data.title
        })

        reset()
    }

    return (
        <div className="max-w-3xl mx-auto rounded-3xl border border-emerald-100 bg-white/90 p-6 shadow-[0_20px_45px_-28px_rgba(16,185,129,0.28)]">
            <form onSubmit={handleSubmit(onSubmit)}>
                <label className="block text-sm font-semibold uppercase tracking-[0.18em] text-slate-600">
                    Add task
                </label>

                <div className="mt-3 flex gap-3">
                    <input
                        type="text"
                        placeholder="e.g. Buy groceries"
                        {...register("title", {
                            required: "Please fill the title"
                        })}
                        className="flex-1 rounded-2xl border border-emerald-100 bg-emerald-50/60 px-4 py-3 text-slate-700 shadow-inner shadow-emerald-100 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-4 focus:ring-emerald-200 focus:border-emerald-300"
                    />

                    <button
                        type="submit"
                        className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold shadow-lg shadow-emerald-200 transition-colors hover:from-emerald-600 hover:to-teal-600 focus:outline-none focus:ring-4 focus:ring-emerald-200"
                    >
                        Add
                    </button>
                </div>

                {errors.title && (
                    <p className="mt-2 text-sm text-rose-500">
                        {errors.title.message}
                    </p>
                )}
            </form>
        </div>
    )
}