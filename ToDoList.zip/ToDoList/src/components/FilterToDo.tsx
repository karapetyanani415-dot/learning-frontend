import { useContext } from "react"
import { ToDoContext } from "../Context/ToDoContext"

const filters = ["All", "Active", "Completed"] as const

export const FilterToDo = () => {
    const context = useContext(ToDoContext)
    if (!context) throw new Error("Out of provider")

    const { state, dispatch } = context

    return (
        <div className="max-w-3xl mx-auto rounded-3xl border border-emerald-100 bg-white/90 p-6 shadow-[0_18px_35px_-28px_rgba(16,185,129,0.28)]">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">Selected: {state.currentFilter}</p>
            <h4 className="mb-3 text-sm font-semibold text-slate-700">Filter</h4>
            <div className="flex items-center gap-2">
                {filters.map(filter => {
                    const isActive = state.currentFilter === filter

                    return (
                        <button
                            key={filter}
                            type="button"
                            onClick={() => dispatch({ type: "SET_FILTER", payload: filter })}
                            className={`px-4 py-2 rounded-full border transition-colors ${isActive
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-200"
                                : "bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100 hover:border-emerald-200"
                                }`}
                        >
                            {filter}
                        </button>
                    )
                })}
            </div>
        </div>
    )
}