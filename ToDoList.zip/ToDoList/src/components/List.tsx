import { useContext } from "react"
import { ToDoContext } from "../Context/ToDoContext"
import { ToDoItem } from "./ToDoItem"

export const List = () => {
    const context = useContext(ToDoContext)
    if (!context) throw new Error("Out of provider")

    const { state: { todos, currentFilter } } = context

    const filteredTodos = todos.filter(todo => {
        if (currentFilter === "Active") return !todo.completed
        if (currentFilter === "Completed") return todo.completed
        return true
    })

    return (
        <section className="max-w-3xl mx-auto rounded-3xl border border-emerald-100 bg-white/90 p-6 shadow-[0_18px_35px_-28px_rgba(16,185,129,0.28)]">
            <h3 className="mb-4 text-2xl font-bold text-emerald-700">Your Tasks</h3>
            <ul className="space-y-3">
                {
                    filteredTodos.map(todo => {
                        return <ToDoItem key={todo.id} todo={todo} />;
                    })
                }
            </ul>
        </section>
    )
}