import { AddToDo } from "./AddToDo"
import { FilterToDo } from "./FilterToDo"
import { List } from "./List"

export const ToDoList = () => {
    return (
        <main className="min-h-screen bg-gradient-to-b from-emerald-50 via-slate-50 to-cyan-50 py-8">
            <div className="max-w-4xl mx-auto px-4">
                <header className="mb-6 rounded-3xl border border-emerald-100 bg-white/80 p-6 shadow-[0_20px_45px_-28px_rgba(16,185,129,0.4)] backdrop-blur-sm">
                    <h1 className="text-3xl font-extrabold text-emerald-700">ToDo — Modern</h1>
                    <p className="text-sm text-slate-600">A clean, focused task list with a fresh green-blue palette</p>
                </header>
                <div className="space-y-4">
                    <AddToDo />
                    <FilterToDo />
                    <List />
                </div>
            </div>
        </main>
    )
}