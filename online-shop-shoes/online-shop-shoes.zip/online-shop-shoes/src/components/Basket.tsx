import type { BasketItem } from "../helpers/types";

type Props = {
  items: BasketItem[];
  onQuantityUp: (id: number) => void;
  onQuantityDown: (id: number) => void;
  onDelete: (id: number) => void;
};

export const Basket: React.FC<Props> = ({
  items,
  onQuantityUp,
  onQuantityDown,
  onDelete,
}) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden p-4">
      <h2 className="text-3xl font-bold text-slate-900 mb-6">Basket</h2>
      <table className="w-full">
        <thead>
          <tr className="bg-gradient-to-r from-blue-600 to-blue-700">
            <th className="px-4 py-3 text-left text-sm font-semibold text-white">
              product
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-white">
              price
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-white">
              subtotal
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-white">
              actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {items.map((item) => (
            <tr
              key={item.id}
              className="hover:bg-slate-50 transition-colors duration-200"
            >
              <td className="px-4 py-3 text-sm font-medium text-slate-900">
                {item.name}
              </td>
              <td className="px-4 py-3 text-sm text-slate-600">
                {item.quantity} x ${item.price}
              </td>
              <td className="px-4 py-3 text-sm font-semibold text-blue-600">
                ${item.price * item.quantity}
              </td>
              <td className="px-4 py-3">
                <div className="flex gap-1">
                  <button
                    onClick={() => onDelete(item.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-2.5 py-1 rounded-lg text-sm font-medium transition-colors"
                  >
                    X
                  </button>
                  <button
                    onClick={() => onQuantityUp(item.id)}
                    className="bg-green-500 hover:bg-green-600 text-white px-2.5 py-1 rounded-lg text-sm font-medium transition-colors"
                  >
                    +
                  </button>
                  <button
                    onClick={() => onQuantityDown(item.id)}
                    className="bg-orange-500 hover:bg-orange-600 text-white px-2.5 py-1 rounded-lg text-sm font-medium transition-colors"
                  >
                    -
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
