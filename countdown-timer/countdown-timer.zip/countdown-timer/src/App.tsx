import { useState, useRef } from "react";
import type { Counter } from "./types/counter";
import CounterComponent from "./components/Counter";
import CounterList from "./components/CounterList";

function App() {
    const [counters, setCounters] = useState<Counter[]>([]);
    const nextId = useRef(1);

    const createCounter = () => {
        const newCounter: Counter = {
            id: nextId.current++,
            remainingTime: 10,
            startTime: new Date().toLocaleTimeString(),
            endTime: null,
            completed: false,
            paused: false,
        };

        setCounters([...counters, newCounter]);
    };

    const complete = (id: number) => {
        setCounters(
            counters.map((counter) =>
                counter.id === id
                    ? {
                        ...counter,
                        completed: true,
                        endTime: new Date().toLocaleTimeString(),
                    }
                    : counter
            )
        );
    };

    const togglePause = (id: number) => {
        setCounters(
            counters.map((counter) =>
                counter.id === id
                    ? {
                        ...counter,
                        paused: !counter.paused,
                    }
                    : counter
            )
        );
    };

    const resetCounter = (id: number) => {
        setCounters(
            counters.map((counter) =>
                counter.id === id ? {
                    ...counter, completed: false,
                    paused: false, endTime: null,
                }
                    : counter));
    };

    const deleteCounter = (id: number) => {
        setCounters(
            counters.filter(counter => counter.id !== id)
        );
    };

    return (
        <div>
            <h1>Counter App</h1>

            <button onClick={createCounter}>
                Create
            </button>

            {counters.map((counter) => (
                <CounterComponent
                    key={counter.id}
                    counter={counter}
                    onComplete={() => complete(counter.id)}
                    onPauseToggle={() => togglePause(counter.id)}
                    onReset={() => resetCounter(counter.id)}
                    onDelete={() => deleteCounter(counter.id)}
                />
            ))}

            <CounterList counters={counters} />
        </div>
    );
}

export default App;