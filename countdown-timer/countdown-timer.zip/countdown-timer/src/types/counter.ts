export type Counter = {
  id: number;
  remainingTime: number;
  startTime: string;
  endTime: string | null;
  completed: boolean;
  paused: boolean;
};