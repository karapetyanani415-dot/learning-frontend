import type { Counter } from "../types/counter";
import { useState, useEffect } from "react";

type CounterProps = {
    counter: Counter;
    onComplete: () => void;
    onPauseToggle: () => void;
    onReset: () => void;
    onDelete: () => void;
};

function CounterComponent({
    counter,
    onComplete,
    onPauseToggle,
    onReset,
    onDelete
}: CounterProps) {
    const [remainingTime, setRemainingTime] = useState(counter.remainingTime);

    useEffect(() => {
        if (counter.paused || counter.completed) {
            return;
        }

        const interval = setInterval(() => {
            setRemainingTime((prevTime) => {
                if (prevTime > 1) {
                    return prevTime - 1;
                }

                clearInterval(interval);
                onComplete();
                return 0;
            });
        }, 1000);

        return () => clearInterval(interval);
    }, [counter.paused, counter.completed, onComplete]);

    const handleReset = () => {
        setRemainingTime(counter.remainingTime);
        onReset();
    };

    const minutes = Math.floor(remainingTime / 60);
    const seconds = (remainingTime % 60)
        .toString()
        .padStart(2, "0");

    return (
        <div>
            <h2>Counter {counter.id}</h2>

            <p>
                {minutes}:{seconds}
            </p>

            <button onClick={onPauseToggle}>
                {counter.paused ? "Play" : "Pause"}
            </button>

            <button onClick={handleReset}>
                Stop
            </button>
            <button onClick={onDelete}> Delete </button>
        </div>
    );
}

export default CounterComponent;
