import type { Counter } from "../types/counter";

type CounterListProps = {
    counters: Counter[];
};

function CounterList({ counters }: CounterListProps) {
    return (
        <table>
            <thead>
                <tr>
                    <th>CounterId</th>
                    <th>StartTime</th>
                    <th>EndTime</th>
                    <th>Completed</th>
                </tr>
            </thead>
            
            <tbody>
                {
                    counters.map(counter => {
                        return (<tr key={counter.id}>
                            <td>{counter.id}</td>
                            <td>{counter.startTime}</td>
                            <td>{counter.endTime}</td>
                            <td>{counter.completed ? "true" : "false"}</td>
                        </tr>
                        )
                    })
                }
            </tbody>
        </table>
    );
}

export default CounterList;